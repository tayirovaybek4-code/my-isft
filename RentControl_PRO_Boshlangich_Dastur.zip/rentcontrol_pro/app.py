import streamlit as st
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB=Path(__file__).with_name('rentcontrol.db')
def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c

def init():
 with conn() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS equipment(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT, quantity INTEGER NOT NULL CHECK(quantity>=0), hourly REAL NOT NULL DEFAULT 0, daily REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Soz');
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rentals(id INTEGER PRIMARY KEY, equipment_id INTEGER NOT NULL, client_id INTEGER NOT NULL, quantity INTEGER NOT NULL, start_at TEXT NOT NULL, due_at TEXT NOT NULL, returned_at TEXT, price REAL NOT NULL, penalty_per_day REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0, FOREIGN KEY(equipment_id) REFERENCES equipment(id), FOREIGN KEY(client_id) REFERENCES clients(id));''')

def rows(q,p=()):
 with conn() as c:return [dict(x) for x in c.execute(q,p).fetchall()]

def money(x):return f'{x:,.0f} so‘m'.replace(',',' ')
def overdue(r):
 end=datetime.fromisoformat(r['returned_at']) if r['returned_at'] else datetime.now()
 due=datetime.fromisoformat(r['due_at'])
 seconds=max(0,(end-due).total_seconds())
 return int((seconds+86399)//86400)*r['penalty_per_day'] if seconds else 0

st.set_page_config(page_title='RentControl PRO',page_icon='🏗️',layout='wide')
st.markdown('''<style>.block-container{padding-top:2rem}h1,h2,h3{color:#17345c}div[data-testid="stMetric"]{background:#eef4ff;padding:15px;border-radius:14px}</style>''',unsafe_allow_html=True)
init()
st.title('🏗️ RentControl PRO')
st.caption('Elektr texnikalari va qurilish anjomlari ijarasini boshqarish • Ishchi demo (mahalliy baza)')
page=st.sidebar.radio('Bo‘limlar',['📊 Boshqaruv paneli','🛠️ Uskunalar','👥 Mijozlar','📋 Ijara berish','↩️ Qaytarish va jarimalar','📈 Hisobot'])
allrent=rows('''SELECT r.*,e.name AS equipment,c.name AS client FROM rentals r JOIN equipment e ON e.id=r.equipment_id JOIN clients c ON c.id=r.client_id ORDER BY r.id DESC''')
if page=='📊 Boshqaruv paneli':
 eq=rows('SELECT * FROM equipment'); active=[r for r in allrent if not r['returned_at']]; late=[r for r in active if datetime.fromisoformat(r['due_at'])<datetime.now()]
 a,b,c,d=st.columns(4);a.metric('Uskuna turlari',len(eq));b.metric('Faol ijaralar',len(active));c.metric('Kechikkanlar',len(late));d.metric('Qayd etilgan to‘lovlar',money(sum(r['paid'] for r in allrent)))
 st.subheader('Faol ijaralar');st.dataframe([{'ID':r['id'],'Uskuna':r['equipment'],'Mijoz':r['client'],'Soni':r['quantity'],'Qaytarish':r['due_at'],'Holati':'Kechikkan' if r in late else 'Faol'} for r in active],use_container_width=True)
elif page=='🛠️ Uskunalar':
 st.subheader('Uskuna qo‘shish')
 with st.form('eq'):
  name=st.text_input('Uskuna nomi');cat=st.selectbox('Tur',['Elektr texnika','Qurilish anjomi','Boshqa']);qty=st.number_input('Jami soni',1,10000,1);h=st.number_input('Soatlik tarif (so‘m)',min_value=0.0,step=1000.0);day=st.number_input('Kunlik tarif (so‘m)',min_value=0.0,step=5000.0);status=st.selectbox('Holati',['Soz','Ta’mirda']);submit=st.form_submit_button('Saqlash')
  if submit:
   if not name.strip():st.error('Uskuna nomini kiriting')
   else:
    with conn() as c:c.execute('INSERT INTO equipment(name,category,quantity,hourly,daily,status) VALUES(?,?,?,?,?,?)',(name.strip(),cat,qty,h,day,status))
    st.success('Uskuna qo‘shildi');st.rerun()
 st.subheader('Uskunalar ro‘yxati');st.dataframe(rows('SELECT * FROM equipment'),use_container_width=True)
elif page=='👥 Mijozlar':
 with st.form('client'):
  name=st.text_input('F.I.Sh.');phone=st.text_input('Telefon');ok=st.form_submit_button('Mijozni saqlash')
  if ok:
   if not name.strip() or not phone.strip():st.error('Ism va telefonni kiriting')
   else:
    with conn() as c:c.execute('INSERT INTO clients(name,phone) VALUES(?,?)',(name.strip(),phone.strip()))
    st.success('Mijoz qo‘shildi');st.rerun()
 st.dataframe(rows('SELECT * FROM clients'),use_container_width=True)
elif page=='📋 Ijara berish':
 eq=rows('SELECT * FROM equipment WHERE status="Soz"');clients=rows('SELECT * FROM clients');active=rows('SELECT equipment_id, SUM(quantity) AS used FROM rentals WHERE returned_at IS NULL GROUP BY equipment_id');used={x['equipment_id']:x['used'] for x in active};available=[e for e in eq if e['quantity']>used.get(e['id'],0)]
 if not available or not clients:st.warning('Avval soz uskuna va mijoz qo‘shing. Bo‘sh uskuna ham bo‘lishi kerak.')
 else:
  with st.form('rent'):
   e=st.selectbox('Uskuna',available,format_func=lambda x:f"{x['name']} — bo‘sh: {x['quantity']-used.get(x['id'],0)}")
   client=st.selectbox('Mijoz',clients,format_func=lambda x:f"{x['name']} ({x['phone']})")
   q=st.number_input('Soni',min_value=1,max_value=e['quantity']-used.get(e['id'],0));mode=st.radio('Tarif',['Kunlik','Soatlik'],horizontal=True);duration=st.number_input('Muddat',min_value=1,value=1);penalty=st.number_input('Kechikish jarimasi (har boshlangan kun uchun, so‘m)',min_value=0.0,step=5000.0);paid=st.number_input('Oldindan to‘lov',min_value=0.0,step=5000.0)
   price=q*duration*(e['daily'] if mode=='Kunlik' else e['hourly']);st.info(f'Ijara summasi: {money(price)}')
   if st.form_submit_button('Ijarani rasmiylashtirish'):
    now=datetime.now();due=now+ (timedelta(days=duration) if mode=='Kunlik' else timedelta(hours=duration))
    with conn() as c:c.execute('INSERT INTO rentals(equipment_id,client_id,quantity,start_at,due_at,price,penalty_per_day,paid) VALUES(?,?,?,?,?,?,?,?)',(e['id'],client['id'],q,now.isoformat(timespec='seconds'),due.isoformat(timespec='seconds'),price,penalty,paid))
    st.success('Ijara saqlandi');st.rerun()
elif page=='↩️ Qaytarish va jarimalar':
 active=[r for r in allrent if not r['returned_at']]
 if not active:st.info('Faol ijaralar yo‘q')
 else:
  r=st.selectbox('Ijara',active,format_func=lambda x:f"#{x['id']} — {x['equipment']} — {x['client']}")
  fine=overdue(r);st.write('Asosiy summa:',money(r['price']));st.write('Hozirgi jarima:',money(fine));st.write('To‘langan:',money(r['paid']));st.write('Qoldiq:',money(max(0,r['price']+fine-r['paid'])))
  extra=st.number_input('Hozir qabul qilingan to‘lov',min_value=0.0,step=5000.0)
  if st.button('Qaytarishni tasdiqlash'):
   with conn() as c:c.execute('UPDATE rentals SET returned_at=?, paid=paid+? WHERE id=?',(datetime.now().isoformat(timespec='seconds'),extra,r['id']))
   st.success('Ijara yakunlandi');st.rerun()
elif page=='📈 Hisobot':
 data=[{'Ijara ID':r['id'],'Uskuna':r['equipment'],'Mijoz':r['client'],'Soni':r['quantity'],'Boshlanish':r['start_at'],'Qaytarish muddati':r['due_at'],'Haqiqiy qaytish':r['returned_at'] or 'Faol','Asosiy summa':r['price'],'Jarima':overdue(r),'To‘langan':r['paid'],'Qoldiq':max(0,r['price']+overdue(r)-r['paid'])} for r in allrent]
 st.dataframe(data,use_container_width=True)
 import csv,io
 out=io.StringIO()
 if data:
  w=csv.DictWriter(out,fieldnames=data[0].keys());w.writeheader();w.writerows(data)
 st.download_button('⬇️ CSV hisobot',out.getvalue().encode('utf-8-sig'),'rentcontrol_hisobot.csv','text/csv',disabled=not bool(data))
st.divider();st.caption('Eslatma: bu birinchi mahalliy MVP. Internet orqali ko‘p foydalanuvchili ishlash, login, Telegram/SMS, shartnoma va zaxira nusxa keyingi bosqichda qo‘shiladi.')
