RentControl PRO — birinchi ishchi MVP
1. Python 3.10+ o'rnating.
2. Terminalda loyiha papkasiga kiring.
3. pip install -r requirements.txt
4. streamlit run app.py
5. Brauzerda ochilgan sahifadan foydalaning.
Ma'lumotlar rentcontrol.db faylida mahalliy saqlanadi.
Muhim: bu versiyada autentifikatsiya, SMS/Telegram, bulut sinxronizatsiyasi va zaxira nusxa avtomatik tizimi yo'q. Internetga ochiq serverga himoyasiz joylamang.
