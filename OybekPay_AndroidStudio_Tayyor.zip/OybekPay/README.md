# Oybek Pay — Android Studio loyihasi

Purple-white dizayndagi, **Kotlin + Jetpack Compose** bilan yozilgan to‘liq ishlaydigan E-Wallet demo ilova.

## Ichida bor

- Splash va kirish oynasi
- Bosh sahifa, balans va tranzaksiya tarixi
- Pul o‘tkazish: tekshiruv, tasdiqlash va chek
- Telefon, internet, kommunal hamda TV to‘lovlari
- Kartalar oynasi va demo karta qo‘shish
- Daromad/xarajat statistikasi
- Profil va chiqish funksiyasi
- Barcha ma’lumotlar demo ko‘rinishida, ilova ishga tushgach internetsiz ishlaydi

## Android Studio’da ochish

1. ZIP faylni telefon yoki kompyuterda oching.
2. Android Studio → **Open** → `OybekPay` papkasini tanlang.
3. JDK sifatida **Embedded JDK 17** tanlanganiga ishonch hosil qiling.
4. Internetni yoqib, **Sync Project with Gradle Files** tugmasini bosing.
5. Sync tugagach, ▶ Run tugmasini bosing.

> Birinchi Gradle Sync vaqtida komponentlar yuklanishi uchun internet kerak bo‘ladi. Oldin DNS/Gradle muammosi bo‘lgan bo‘lsa: Settings → HTTP Proxy → **No proxy** qilib, Sync tugmasini yana bosing.

## Muhim

Bu ilova real bank yoki Click API’ga ulanmagan **demo**. Pul o‘tkazish, balans va chek ichki demo ma’lumotlarda ishlaydi. Haqiqiy pul o‘tkazishni ulash uchun bank yoki to‘lov tizimining rasmiy API kalitlari va shartnomasi kerak bo‘ladi.
