package com.oybekpay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Purple = Color(0xFF5A16D6)
private val DarkPurple = Color(0xFF2F075F)
private val Violet = Color(0xFF8F45FF)
private val Lavender = Color(0xFFF5F1FF)
private val AppBackground = Color(0xFFF9F8FD)
private val Ink = Color(0xFF211A31)
private val Muted = Color(0xFF817A90)
private val Green = Color(0xFF13B47A)
private val Red = Color(0xFFEA5B72)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OybekPayTheme {
                OybekPayApp()
            }
        }
    }
}

private data class WalletTransaction(
    val title: String,
    val subtitle: String,
    val amount: Long,
    val isIncome: Boolean,
    val symbol: String
)

private data class WalletCard(
    val owner: String,
    val maskedNumber: String,
    val scheme: String,
    val primary: Boolean
)

private data class NavItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
private fun OybekPayApp() {
    var splashComplete by rememberSaveable { mutableStateOf(false) }
    var signedIn by rememberSaveable { mutableStateOf(false) }
    var route by rememberSaveable { mutableStateOf("home") }
    var balance by rememberSaveable { mutableStateOf(3_215_500L) }

    val transactions = remember {
        mutableStateListOf(
            WalletTransaction("Kartaga tushum", "Bugun, 10:30", 3_000_000, true, "↓"),
            WalletTransaction("Beeline", "Kecha, 20:12", 75_000, false, "B"),
            WalletTransaction("Supermarket", "Kecha, 14:45", 186_500, false, "S"),
            WalletTransaction("Oybek aka", "14 oktabr, 09:21", 450_000, true, "O")
        )
    }
    val cards = remember {
        mutableStateListOf(
            WalletCard("OYBEK TOIROV", "•••• 1458", "UZCARD", true),
            WalletCard("OYBEK TOIROV", "•••• 8093", "HUMO", false)
        )
    }

    LaunchedEffect(Unit) {
        delay(1_150)
        splashComplete = true
    }

    when {
        !splashComplete -> SplashScreen()
        !signedIn -> LoginScreen(onLogin = {
            signedIn = true
            route = "home"
        })
        else -> WalletShell(
            route = route,
            balance = balance,
            transactions = transactions,
            cards = cards,
            onRouteChange = { route = it },
            onTransfer = { recipient, amount, note ->
                balance -= amount
                transactions.add(
                    0,
                    WalletTransaction(
                        title = recipient,
                        subtitle = "Hozir, ${timeNow()}${note.takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}",
                        amount = amount,
                        isIncome = false,
                        symbol = "↑"
                    )
                )
            },
            onPayment = { title, amount ->
                balance -= amount
                transactions.add(
                    0,
                    WalletTransaction(
                        title = title,
                        subtitle = "Hozir, ${timeNow()}",
                        amount = amount,
                        isIncome = false,
                        symbol = "₴"
                    )
                )
            },
            onCardAdd = { owner, digits ->
                cards.add(
                    0,
                    WalletCard(
                        owner = owner.uppercase(Locale.getDefault()),
                        maskedNumber = "•••• ${digits.takeLast(4)}",
                        scheme = "UZCARD",
                        primary = cards.isEmpty()
                    )
                )
            },
            onLogout = { signedIn = false }
        )
    }
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkPurple, Purple, Violet))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.AccountBalanceWallet,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(46.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text("Oybek Pay", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Qulay. Tez. Ishonchli.", color = Color.White.copy(alpha = 0.78f), fontSize = 15.sp)
            Spacer(Modifier.height(38.dp))
            Text("Yuklanmoqda...", color = Color.White.copy(alpha = 0.72f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun LoginScreen(onLogin: () -> Unit) {
    var phone by rememberSaveable { mutableStateOf("") }
    var pin by rememberSaveable { mutableStateOf("") }
    var pinVisible by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 34.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Purple, Violet))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.AccountBalanceWallet, null, tint = Color.White, modifier = Modifier.size(31.dp))
            }
            Spacer(Modifier.height(36.dp))
            Text("Xush kelibsiz!", color = Ink, fontWeight = FontWeight.Bold, fontSize = 30.sp)
            Spacer(Modifier.height(8.dp))
            Text("Oybek Pay hisobingizga kiring", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.height(32.dp))

            Text("Telefon raqami", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = phone,
                onValueChange = {
                    phone = it.filter { char -> char.isDigit() || char == '+' || char == ' ' }
                    error = ""
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                prefix = { Text("+998 ", color = Purple, fontWeight = FontWeight.Bold) },
                placeholder = { Text("90 123 45 67") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(16.dp),
                colors = textFieldColors()
            )
            Spacer(Modifier.height(20.dp))
            Text("PIN-kod", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = {
                    pin = it.filter { char -> char.isDigit() }.take(4)
                    error = ""
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("••••") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = if (pinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { pinVisible = !pinVisible }) {
                        Icon(
                            if (pinVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = "PIN-kodni ko‘rsatish",
                            tint = Muted
                        )
                    }
                },
                shape = RoundedCornerShape(16.dp),
                colors = textFieldColors()
            )
            if (error.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(error, color = Red, fontSize = 13.sp)
            }
            Spacer(Modifier.height(28.dp))
            Button(
                onClick = {
                    when {
                        phone.filter { it.isDigit() }.length < 9 -> error = "Telefon raqamini to‘liq kiriting"
                        pin.length != 4 -> error = "4 xonali PIN-kod kiriting"
                        else -> onLogin()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                Text("Kirish", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(
            "Demo rejim: istalgan telefon raqami va 4 xonali PIN bilan kirishingiz mumkin.",
            color = Muted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 36.dp)
        )
    }
}

@Composable
private fun WalletShell(
    route: String,
    balance: Long,
    transactions: List<WalletTransaction>,
    cards: List<WalletCard>,
    onRouteChange: (String) -> Unit,
    onTransfer: (String, Long, String) -> Unit,
    onPayment: (String, Long) -> Unit,
    onCardAdd: (String, String) -> Unit,
    onLogout: () -> Unit
) {
    val rootRoutes = setOf("home", "stats", "cards", "profile")
    Scaffold(
        containerColor = AppBackground,
        bottomBar = {
            if (route in rootRoutes) {
                WalletBottomBar(currentRoute = route, onRouteChange = onRouteChange)
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (route) {
                "home" -> HomeScreen(
                    balance = balance,
                    transactions = transactions,
                    onRouteChange = onRouteChange
                )
                "transfer" -> TransferScreen(
                    balance = balance,
                    onBack = { onRouteChange("home") },
                    onSend = onTransfer,
                    onDone = { onRouteChange("home") }
                )
                "payments" -> PaymentsScreen(
                    balance = balance,
                    onBack = { onRouteChange("home") },
                    onPay = onPayment,
                    onDone = { onRouteChange("home") }
                )
                "history" -> TransactionsScreen(
                    transactions = transactions,
                    onBack = { onRouteChange("home") }
                )
                "stats" -> StatisticsScreen(transactions = transactions)
                "cards" -> CardsScreen(cards = cards, onAddCard = onCardAdd)
                "profile" -> ProfileScreen(onLogout = onLogout)
            }
        }
    }
}

@Composable
private fun WalletBottomBar(currentRoute: String, onRouteChange: (String) -> Unit) {
    val items = listOf(
        NavItem("home", "Bosh sahifa", Icons.Filled.Home),
        NavItem("stats", "Statistika", Icons.Filled.BarChart),
        NavItem("cards", "Kartalar", Icons.Filled.CreditCard),
        NavItem("profile", "Profil", Icons.Filled.Person)
    )
    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = { onRouteChange(item.route) },
                icon = { Icon(item.icon, item.label) },
                label = { Text(item.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Purple,
                    selectedTextColor = Purple,
                    indicatorColor = Lavender,
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}

@Composable
private fun HomeScreen(
    balance: Long,
    transactions: List<WalletTransaction>,
    onRouteChange: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppBackground),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Assalomu alaykum,", color = Muted, fontSize = 14.sp)
                    Text("Oybek aka", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Purple, Violet))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("OT", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { BalanceCard(balance = balance, onAddMoney = { onRouteChange("transfer") }) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tezkor amallar", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction(
                        label = "O‘tkazma",
                        hint = "Pul yuborish",
                        icon = Icons.Filled.Send,
                        modifier = Modifier.weight(1f),
                        onClick = { onRouteChange("transfer") }
                    )
                    QuickAction(
                        label = "To‘lovlar",
                        hint = "Xizmatlar",
                        icon = Icons.Filled.Payments,
                        modifier = Modifier.weight(1f),
                        onClick = { onRouteChange("payments") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction(
                        label = "Kartalar",
                        hint = "Boshqarish",
                        icon = Icons.Filled.AddCard,
                        modifier = Modifier.weight(1f),
                        onClick = { onRouteChange("cards") }
                    )
                    QuickAction(
                        label = "Cheklar",
                        hint = "Tarix",
                        icon = Icons.Filled.ReceiptLong,
                        modifier = Modifier.weight(1f),
                        onClick = { onRouteChange("history") }
                    )
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Oxirgi operatsiyalar", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { onRouteChange("history") }) {
                    Text("Barchasi", color = Purple, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        items(transactions.take(4)) { transaction -> TransactionRow(transaction) }
    }
}

@Composable
private fun BalanceCard(balance: Long, onAddMoney: () -> Unit) {
    var shown by rememberSaveable { mutableStateOf(true) }
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .background(Brush.linearGradient(listOf(DarkPurple, Purple, Violet)))
                .padding(22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Umumiy balans", color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { shown = !shown }) {
                    Icon(
                        if (shown) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = "Balansni yashirish",
                        tint = Color.White
                    )
                }
            }
            Text(
                if (shown) money(balance) else "••••••••",
                color = Color.White,
                fontSize = 31.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(23.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Asosiy karta", color = Color.White.copy(alpha = 0.68f), fontSize = 12.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("UZCARD  •••• 1458", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                TextButton(
                    onClick = onAddMoney,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.White),
                    modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.44f), RoundedCornerShape(14.dp))
                ) {
                    Text("Yuborish", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    label: String,
    hint: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White)
            .clickable(onClick = onClick)
            .padding(15.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Lavender),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(label, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(hint, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TransactionRow(transaction: WalletTransaction) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (transaction.isIncome) Color(0xFFE8FFF6) else Lavender),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = transaction.symbol,
                color = if (transaction.isIncome) Green else Purple,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(transaction.title, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(transaction.subtitle, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(
            text = (if (transaction.isIncome) "+" else "−") + money(transaction.amount),
            color = if (transaction.isIncome) Green else Ink,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun TransferScreen(
    balance: Long,
    onBack: () -> Unit,
    onSend: (String, Long, String) -> Unit,
    onDone: () -> Unit
) {
    var recipient by rememberSaveable { mutableStateOf("") }
    var amountText by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var showConfirmation by rememberSaveable { mutableStateOf(false) }
    var showReceipt by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf("") }
    val amount = parseAmount(amountText)

    Box(modifier = Modifier.fillMaxSize()) {
        DetailScaffold(title = "Pul o‘tkazish", onBack = onBack) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Lavender), shape = RoundedCornerShape(20.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AccountBalanceWallet, null, tint = Purple)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Mavjud balans", color = Muted, fontSize = 12.sp)
                                Text(money(balance), color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                    }
                }
                item {
                    InputTitle("Qabul qiluvchi")
                    OutlinedTextField(
                        value = recipient,
                        onValueChange = { recipient = it; error = "" },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Ism yoki karta raqami") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = textFieldColors()
                    )
                }
                item {
                    InputTitle("Summa")
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { char -> char.isDigit() || char == ' ' }; error = "" },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("0 so‘m") },
                        suffix = { Text("so‘m", color = Purple, fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(16.dp),
                        colors = textFieldColors()
                    )
                }
                item {
                    InputTitle("Izoh (ixtiyoriy)")
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it.take(32) },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Masalan: qarz") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = textFieldColors()
                    )
                }
                if (error.isNotEmpty()) {
                    item { Text(error, color = Red, fontSize = 13.sp) }
                }
                item {
                    Button(
                        onClick = {
                            error = when {
                                recipient.trim().length < 3 -> "Qabul qiluvchini kiriting"
                                amount == null || amount <= 0L -> "To‘g‘ri summa kiriting"
                                amount > balance -> "Balans yetarli emas"
                                else -> ""
                            }
                            if (error.isEmpty()) showConfirmation = true
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text("Davom etish", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                }
            }
        }
        if (showConfirmation && amount != null) {
            ConfirmDialog(
                title = "O‘tkazmani tasdiqlang",
                lines = listOf("Kimga" to recipient, "Summa" to money(amount), "Komissiya" to "0 so‘m"),
                buttonText = "Tasdiqlash",
                onDismiss = { showConfirmation = false },
                onConfirm = {
                    onSend(recipient.trim(), amount, note.trim())
                    showConfirmation = false
                    showReceipt = true
                }
            )
        }
        if (showReceipt && amount != null) {
            ReceiptDialog(
                title = "O‘tkazma bajarildi",
                description = "Pul muvaffaqiyatli yuborildi",
                recipient = recipient,
                amount = amount,
                onDone = {
                    showReceipt = false
                    onDone()
                }
            )
        }
    }
}

@Composable
private fun PaymentsScreen(
    balance: Long,
    onBack: () -> Unit,
    onPay: (String, Long) -> Unit,
    onDone: () -> Unit
) {
    var selected by rememberSaveable { mutableStateOf("Telefon") }
    var account by rememberSaveable { mutableStateOf("") }
    var amountText by rememberSaveable { mutableStateOf("") }
    var showConfirmation by rememberSaveable { mutableStateOf(false) }
    var showReceipt by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf("") }
    val amount = parseAmount(amountText)
    val categories = listOf(
        "Telefon" to "📱",
        "Internet" to "◉",
        "Kommunal" to "⚡",
        "TV va media" to "▶"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        DetailScaffold(title = "To‘lovlar", onBack = onBack) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Text("Xizmatni tanlang", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        categories.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                pair.forEach { (name, symbol) ->
                                    PaymentCategory(
                                        name = name,
                                        symbol = symbol,
                                        selected = selected == name,
                                        modifier = Modifier.weight(1f),
                                        onClick = { selected = name; error = "" }
                                    )
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Lavender), shape = RoundedCornerShape(20.dp)) {
                        Text(
                            "Balans: ${money(balance)}",
                            color = Purple,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                item {
                    InputTitle("Abonent raqami")
                    OutlinedTextField(
                        value = account,
                        onValueChange = { account = it; error = "" },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Telefon yoki shaxsiy hisob") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = textFieldColors()
                    )
                }
                item {
                    InputTitle("To‘lov summasi")
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { char -> char.isDigit() || char == ' ' }; error = "" },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("0 so‘m") },
                        suffix = { Text("so‘m", color = Purple, fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(16.dp),
                        colors = textFieldColors()
                    )
                }
                if (error.isNotEmpty()) item { Text(error, color = Red, fontSize = 13.sp) }
                item {
                    Button(
                        onClick = {
                            error = when {
                                account.trim().length < 4 -> "Abonent raqamini kiriting"
                                amount == null || amount <= 0L -> "To‘g‘ri summa kiriting"
                                amount > balance -> "Balans yetarli emas"
                                else -> ""
                            }
                            if (error.isEmpty()) showConfirmation = true
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text("To‘lash", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                }
            }
        }
        if (showConfirmation && amount != null) {
            ConfirmDialog(
                title = "To‘lovni tasdiqlang",
                lines = listOf("Xizmat" to selected, "Hisob" to account, "Summa" to money(amount)),
                buttonText = "To‘lash",
                onDismiss = { showConfirmation = false },
                onConfirm = {
                    onPay(selected, amount)
                    showConfirmation = false
                    showReceipt = true
                }
            )
        }
        if (showReceipt && amount != null) {
            ReceiptDialog(
                title = "To‘lov bajarildi",
                description = "$selected uchun to‘lov qabul qilindi",
                recipient = account,
                amount = amount,
                onDone = {
                    showReceipt = false
                    onDone()
                }
            )
        }
    }
}

@Composable
private fun PaymentCategory(
    name: String,
    symbol: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Lavender else Color.White)
            .border(if (selected) 1.dp else 0.dp, if (selected) Purple else Color.Transparent, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(15.dp)
    ) {
        Text(symbol, fontSize = 23.sp)
        Spacer(Modifier.height(8.dp))
        Text(name, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TransactionsScreen(transactions: List<WalletTransaction>, onBack: () -> Unit) {
    DetailScaffold(title = "Tranzaksiyalar", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Barcha operatsiyalar", color = Muted, fontSize = 14.sp)
            }
            items(transactions) { TransactionRow(it) }
        }
    }
}

@Composable
private fun StatisticsScreen(transactions: List<WalletTransaction>) {
    val spent = transactions.filterNot { it.isIncome }.sumOf { it.amount }
    val received = transactions.filter { it.isIncome }.sumOf { it.amount }
    val max = maxOf(received, spent, 1L)
    val chartValues = listOf(0.33f, 0.61f, 0.48f, 0.85f, 0.57f, 0.73f, (spent.toFloat() / max).coerceIn(0.25f, 1f))
    val labels = listOf("D", "S", "CH", "P", "J", "SH", "Y")

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppBackground),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Statistika", color = Ink, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Text("Bu oy bo‘yicha hisobotingiz", color = Muted, fontSize = 14.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SummaryCard(
                    label = "Kirim",
                    value = money(received),
                    tint = Green,
                    modifier = Modifier.weight(1f)
                )
                SummaryCard(
                    label = "Chiqim",
                    value = money(spent),
                    tint = Red,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Analytics, null, tint = Purple)
                        Spacer(Modifier.width(8.dp))
                        Text("Haftalik xarajatlar", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                    Spacer(Modifier.height(22.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().height(148.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        chartValues.forEachIndexed { index, value ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                Box(
                                    modifier = Modifier
                                        .width(23.dp)
                                        .height((100f * value).dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(if (index == chartValues.lastIndex) Purple else Color(0xFFDCC9FF))
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(labels[index], color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Lavender),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Eng katta xarajat", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        transactions.filterNot { it.isIncome }.maxByOrNull { it.amount }?.title ?: "Hali xarajat yo‘q",
                        color = Ink,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(money(transactions.filterNot { it.isIncome }.maxOfOrNull { it.amount } ?: 0), color = Purple, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Box(modifier = Modifier.size(9.dp).clip(CircleShape).background(tint))
            Spacer(Modifier.height(12.dp))
            Text(label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun CardsScreen(cards: List<WalletCard>, onAddCard: (String, String) -> Unit) {
    var showAddDialog by rememberSaveable { mutableStateOf(false) }
    var cardNumber by rememberSaveable { mutableStateOf("") }
    var owner by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize().background(AppBackground)) {
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Text("Kartalar", color = Ink, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                Text("Kartalaringizni boshqaring", color = Muted, fontSize = 14.sp)
            }
            items(cards) { card -> WalletCardView(card) }
            item {
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)
                ) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Karta qo‘shish", fontWeight = FontWeight.Bold)
                }
            }
            item {
                Text("Kartalar demo rejimida ishlaydi. Karta qo‘shilgach, u shu ilova ichida ko‘rinadi.", color = Muted, fontSize = 12.sp)
            }
        }
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Karta qo‘shish", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { cardNumber = it.filter { char -> char.isDigit() }.take(16); error = "" },
                            label = { Text("Karta raqami") },
                            placeholder = { Text("8600 0000 0000 0000") },
                            singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(14.dp),
                            colors = textFieldColors()
                        )
                        OutlinedTextField(
                            value = owner,
                            onValueChange = { owner = it; error = "" },
                            label = { Text("Karta egasi") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = textFieldColors()
                        )
                        if (error.isNotEmpty()) Text(error, color = Red, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (cardNumber.length != 16 || owner.trim().length < 3) {
                            error = "16 xonali karta raqami va karta egasini kiriting"
                        } else {
                            onAddCard(owner.trim(), cardNumber)
                            cardNumber = ""
                            owner = ""
                            showAddDialog = false
                        }
                    }) { Text("Qo‘shish", color = Purple, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Bekor qilish", color = Muted) } }
            )
        }
    }
}

@Composable
private fun WalletCardView(card: WalletCard) {
    val colors = if (card.primary) listOf(DarkPurple, Purple, Violet) else listOf(Color(0xFF212A3B), Color(0xFF485877), Color(0xFF7788AA))
    Card(
        modifier = Modifier.fillMaxWidth().requiredHeight(190.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(25.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(card.scheme, color = Color.White.copy(alpha = 0.84f), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.CreditCard, null, tint = Color.White, modifier = Modifier.size(23.dp))
            }
            Text(card.maskedNumber, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("KARTA EGASI", color = Color.White.copy(alpha = 0.56f), fontSize = 9.sp)
                    Text(card.owner, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                if (card.primary) {
                    Text("ASOSIY", color = Color.White.copy(alpha = 0.82f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(onLogout: () -> Unit) {
    var confirmLogout by rememberSaveable { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppBackground),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Profil", color = Ink, fontWeight = FontWeight.Bold, fontSize = 28.sp)
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color.White).padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Violet))),
                    contentAlignment = Alignment.Center
                ) { Text("OT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Oybek Toirov", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("+998 90 123 45 67", color = Muted, fontSize = 13.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
        }
        item { Text("SOZLAMALAR", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 8.dp)) }
        item {
            Column(modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(Color.White)) {
                ProfileRow(Icons.Filled.Settings, "Hisob sozlamalari", "Til va bildirishnomalar")
                DividerLine()
                ProfileRow(Icons.Filled.ReceiptLong, "Operatsiyalar tarixi", "Barcha cheklar")
                DividerLine()
                ProfileRow(Icons.Filled.Analytics, "Xavfsizlik", "PIN-kod va himoya")
            }
        }
        item {
            Button(
                onClick = { confirmLogout = true },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFEEF1), contentColor = Red),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Filled.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Hisobdan chiqish", fontWeight = FontWeight.Bold)
            }
        }
        item {
            Text("Oybek Pay 1.0.0 • Demo versiya", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text("Hisobdan chiqilsinmi?") },
            text = { Text("Qayta kirish uchun telefon raqami va PIN-kodni yozasiz.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLogout = false
                    onLogout()
                }) { Text("Chiqish", color = Red, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("Bekor qilish", color = Muted) } }
        )
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, title: String, subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Lavender),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Purple, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DividerLine() {
    Spacer(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF0EDF5)).padding(start = 68.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScaffold(title: String, onBack: () -> Unit, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        containerColor = AppBackground,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Orqaga", tint = Ink)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = AppBackground)
            )
        },
        content = content
    )
}

@Composable
private fun InputTitle(text: String) {
    Text(text, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun ConfirmDialog(
    title: String,
    lines: List<Pair<String, String>>,
    buttonText: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                lines.forEach { (label, value) ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = Muted, fontSize = 13.sp)
                        Text(value, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.End)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(buttonText, color = Purple, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Bekor qilish", color = Muted) }
        }
    )
}

@Composable
private fun ReceiptDialog(
    title: String,
    description: String,
    recipient: String,
    amount: Long,
    onDone: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDone,
        icon = { Icon(Icons.Filled.CheckCircle, null, tint = Green, modifier = Modifier.size(54.dp)) },
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(description, color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                Text(money(amount), color = Purple, fontWeight = FontWeight.Bold, fontSize = 27.sp)
                Spacer(Modifier.height(14.dp))
                Text(recipient, color = Ink, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("${dateToday()}, ${timeNow()}", color = Muted, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = onDone,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Tayyor", fontWeight = FontWeight.Bold) }
        }
    )
}

@Composable
private fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Purple,
    focusedLabelColor = Purple,
    cursorColor = Purple,
    unfocusedBorderColor = Color(0xFFDCD6E8),
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White
)

@Composable
private fun OybekPayTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Purple,
        onPrimary = Color.White,
        primaryContainer = Lavender,
        secondary = Violet,
        background = AppBackground,
        surface = Color.White,
        onSurface = Ink
    )
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}

private fun money(value: Long): String = DecimalFormat("#,###").format(value).replace(',', ' ') + " so‘m"

private fun parseAmount(text: String): Long? = text.filter { it.isDigit() }.toLongOrNull()

private fun timeNow(): String = SimpleDateFormat("HH:mm", Locale("uz", "UZ")).format(Date())

private fun dateToday(): String = SimpleDateFormat("dd MMMM yyyy", Locale("uz", "UZ")).format(Date())
